// Active-inference engine: real host sensors, security gate, incident lifecycle, health tracking.
import path from "node:path";
import fs from "node:fs";
import os from "node:os";
import * as S from "./sensors.js";
import { scanPath, inspect, quarantine } from "./scanner.js";
import { push, data, setSetting, getSetting, HOME } from "./store.js";
import { analyze } from "./ai.js";
import { analyzeProcess, analyzeConnection } from "./local-ai.js";

const QUARANTINE = path.join(HOME, "quarantine");

// ─── BELIEF MODEL ────────────────────────────────────────────────────────────
const belief = {
  cpu:   { mu: 15,  sigma: 12 },
  mem:   { mu: 50,  sigma: 15 },
  procs: { mu: 150, sigma: 30 },
  conns: { mu: 40,  sigma: 20 },
};
const LR = 0.08;

function surprise(key, x) {
  const b = belief[key];
  const z = Math.abs(x - b.mu) / Math.max(b.sigma, 1);
  return { z, bits: 0.5 * z * z };
}
function learn(key, x) {
  const b = belief[key];
  b.mu += LR * (x - b.mu);
  b.sigma = Math.max(3, b.sigma + LR * (Math.abs(x - b.mu) - b.sigma));
}

// ─── SCORING ENGINE (0-100) ───────────────────────────────────────────────────
function scoreRule(rule, severity, surpriseBits) {
  const base = { critical: 90, high: 70, medium: 45, low: 20 }[severity] ?? 30;
  const surpriseBoost = Math.min(20, surpriseBits * 2);
  return Math.min(100, Math.round(base + surpriseBoost));
}

// ─── GATE DECISION ────────────────────────────────────────────────────────────
// ALLOW(0-low) / HOLD(medium) / QUARANTINE(high) / BLOCK(critical)
function gateDecision(score) {
  const s = data().settings;
  const thLow  = Number(s.thresh_low    ?? 20);
  const thMed  = Number(s.thresh_medium ?? 45);
  const thHigh = Number(s.thresh_high   ?? 70);
  if (score >= thHigh) return "quarantine";
  if (score >= thMed)  return "hold";
  if (score >= thLow)  return "monitor";
  return "allow";
}

// ─── EVENT BUS ───────────────────────────────────────────────────────────────
let listeners = [];
export function onEvent(fn) {
  listeners.push(fn);
  return () => { listeners = listeners.filter(l => l !== fn); };
}
function emit(type, payload) {
  for (const l of listeners) try { l(type, payload); } catch { /* listener gone */ }
}

// ─── LOGGING ──────────────────────────────────────────────────────────────────
export function log(level, source, message, meta) {
  const row = push("events", { level, source, message, meta: meta ?? null });
  emit("event", row);
  return row;
}

// ─── HEALTH TRACKING ──────────────────────────────────────────────────────────
const health = {
  sensors:  { status: "starting", lastOk: null, restarts: 0 },
  scanner:  { status: "idle",     lastOk: null, restarts: 0 },
  network:  { status: "starting", lastOk: null, restarts: 0 },
  database: { status: "ok",       lastOk: Date.now(), restarts: 0 },
  ai:       { status: "unknown",  lastOk: null, restarts: 0 },
};
export function getHealth() { return health; }
function setHealth(svc, status) {
  health[svc].status = status;
  if (status === "ok") health[svc].lastOk = Date.now();
}

// ─── APPROVAL QUEUE ───────────────────────────────────────────────────────────
// Actions needing human approval before execution
const pendingApprovals = new Map();
let approvalSeq = 0;

export function getPendingApprovals() {
  return [...pendingApprovals.values()];
}
export function approveAction(id, approved) {
  const item = pendingApprovals.get(id);
  if (!item) return false;
  item.resolve(approved);
  pendingApprovals.delete(id);
  log("info", "approval", `Action ${id} ${approved ? "approved" : "denied"} by user`, null);
  return true;
}

function requireApproval(action, description, detail) {
  return new Promise(resolve => {
    const id = `appr-${++approvalSeq}`;
    const item = { id, action, description, detail, at: new Date().toISOString(), resolve };
    pendingApprovals.set(id, item);
    emit("approval_required", { id, action, description, detail, at: item.at });
    log("warn", "gate", `Awaiting approval: ${description}`, { id });
    // Timeout: 5 minutes → auto-deny for safety
    setTimeout(() => {
      if (pendingApprovals.has(id)) {
        item.resolve(false);
        pendingApprovals.delete(id);
        log("warn", "gate", `Approval timeout — action denied: ${description}`, { id });
      }
    }, 300_000);
  });
}

// ─── AUDIT LOG (append-only) ──────────────────────────────────────────────────
const AUDIT_FILE = path.join(HOME, "audit.log");
function audit(action, detail) {
  const line = JSON.stringify({ ts: new Date().toISOString(), action, detail }) + "\n";
  try { fs.appendFileSync(AUDIT_FILE, line); } catch { /* disk full etc */ }
}

// ─── THREAT RECORD + AI ───────────────────────────────────────────────────────
export async function recordThreat(t) {
  const score = scoreRule(t.rule, t.severity, t.surpriseBits ?? 0);
  const decision = gateDecision(score);

  // Check allowlist
  const allowlist = data().settings.allowlist ?? [];
  const trusted = allowlist.some(a => t.file?.includes(a) || t.hash === a || t.name?.includes(a));
  const finalDecision = trusted ? "allow" : decision;

  const row = push("threats", {
    status: "flagged",
    score,
    decision: finalDecision,
    ...t,
  });
  emit("threat", row);
  audit("threat_detected", { id: row.id, name: t.name, score, decision: finalDecision });

  log(
    t.severity === "critical" ? "critical" : "warn",
    "response",
    `${t.name} — score=${score} → ${finalDecision}`,
    { file: t.file, score, decision: finalDecision }
  );

  // Apply gate decision (enforcement mode checks)
  const s = data().settings;
  if (finalDecision === "quarantine" && s.enforce_quarantine) {
    // Quarantine is non-reversible without approval — always ask
    const ok = await requireApproval(
      "quarantine",
      `Quarantine file: ${path.basename(t.file || t.name)}`,
      `File: ${t.file || "—"}\nHash: ${t.hash || "—"}\nScore: ${score}/100\nRule: ${t.rule}`
    );
    if (ok && t.file && fs.existsSync(t.file)) {
      try {
        const dest = quarantine(t.file, QUARANTINE);
        row.status = "quarantined";
        row.quarantine_path = dest;
        audit("quarantine_applied", { id: row.id, file: t.file, dest });
        log("warn", "gate", `Quarantined: ${t.file} → ${dest}`, null);
        emit("threat", row);
      } catch (e) {
        log("error", "gate", `Quarantine failed: ${e.message}`, null);
      }
    } else if (!ok) {
      row.status = "held";
      audit("quarantine_denied", { id: row.id, file: t.file });
      emit("threat", row);
    }
  } else if (finalDecision === "hold" && s.enforce_hold) {
    row.status = "held";
    emit("threat", row);
    audit("hold_applied", { id: row.id });
  } else if (finalDecision !== "allow") {
    row.status = "contained";
    emit("threat", row);
  }

  // AI analysis (non-blocking)
  if (s.ai_enabled !== false) {
    analyze(row).then(verdict => {
      if (verdict) {
        row.ai = verdict;
        emit("threat", row);
        log("info", "ai", `AI analysis: ${verdict.behavior_summary || "complete"}`, null);
        setHealth("ai", "ok");
      }
    }).catch(() => { setHealth("ai", "degraded"); });
  }

  return row;
}

// ─── PERSISTENCE MONITORING ──────────────────────────────────────────────────
let knownStartup = new Set();
async function checkPersistence() {
  try {
    const isWin = process.platform === "win32";
    if (!isWin) return;
    const { execFile } = await import("node:child_process");
    const { promisify } = await import("node:util");
    const run = promisify(execFile);
    // Check run keys
    const { stdout } = await run("powershell", [
      "-NoProfile", "-Command",
      `Get-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run' -ErrorAction SilentlyContinue | ConvertTo-Json -Compress`
    ]);
    const entries = JSON.parse(stdout || "{}");
    const keys = Object.keys(entries).filter(k => !k.startsWith("PS"));
    const newKeys = keys.filter(k => !knownStartup.has(k));
    if (newKeys.length > 0 && knownStartup.size > 0) {
      for (const k of newKeys) {
        log("warn", "persistence", `New startup entry detected: ${k} = ${entries[k]}`, null);
        await recordThreat({
          name: `Startup persistence: ${k}`,
          rule: "STARTUP-KEY",
          severity: "high",
          file: null,
          hash: null,
          action: "monitor",
          source: "persistence",
          surpriseBits: 8,
        });
      }
    }
    knownStartup = new Set(keys);
  } catch { /* no powershell or access denied */ }
}

// ─── MAIN SENSOR TICK ────────────────────────────────────────────────────────
let knownVolumes = new Set();
let running = false;
let ticks = 0;

async function tick() {
  ticks++;
  setHealth("sensors", "ok");

  const cpu = S.cpuUsage();
  const mem = S.memory();

  const [procs, procTree, conns, vols, dsk] = await Promise.all([
    S.processes().catch(() => []),
    S.processTree().catch(() => []),
    S.connections().catch(() => []),
    S.volumes().catch(() => []),
    S.disks().catch(() => []),
  ]).then(r => { setHealth("network", "ok"); return r; }).catch(e => {
    setHealth("sensors", "degraded");
    throw e;
  });

  const metric = {
    cpu:   Number(cpu.toFixed(1)),
    mem:   Number(mem.pct.toFixed(1)),
    procs: procs.length,
    conns: conns.length,
  };

  const sCpu  = surprise("cpu",   metric.cpu);
  const sConn = surprise("conns", metric.conns);
  const totalBits = Number((sCpu.bits + sConn.bits).toFixed(2));

  const row = push("metrics", { ...metric, surprise: totalBits });
  emit("metric", { ...row, belief, disks: dsk, host: S.host() });

  learn("cpu",   metric.cpu);
  learn("mem",   metric.mem);
  learn("procs", metric.procs);
  learn("conns", metric.conns);

  if (ticks > 6 && sCpu.z > 4) {
    const top = procs[0];
    log("warn", "inference",
      `Suspicious CPU load ${metric.cpu}% (z=${sCpu.z.toFixed(1)}), top: ${top?.name ?? "?"}`, null);
  }
  if (ticks > 6 && sConn.z > 4) {
    log("warn", "inference",
      `Unusual connections: ${metric.conns} (z=${sConn.z.toFixed(1)})`, null);
  }

  // Analyze process tree for suspicious patterns
  for (const tree of procTree) {
    const analysis = analyzeProcess(tree);
    if (analysis.is_suspicious) {
      log("warn", "process-scan", 
        `Suspicious process tree: ${tree.name} (${analysis.risk_level}) - ${analysis.indicators.join(", ")}`, 
        { pid: tree.pid, indicators: analysis.indicators });
      
      // Create alert if high risk
      if (analysis.risk_level === 'high') {
        push("alerts", {
          level: "warn",
          title: `Suspicious Process: ${tree.name}`,
          message: `Process ${tree.name} (PID ${tree.pid}) exhibits suspicious behavior: ${analysis.indicators.join(", ")}`,
          source: "process-monitor",
          status: "open"
        });
      }
    }
  }

  // Analyze network connections
  for (const conn of conns) {
    const analysis = analyzeConnection(conn);
    if (analysis.is_suspicious) {
      log("warn", "network-scan",
        `Suspicious connection: ${conn.local} -> ${conn.remote} - ${analysis.indicators.join(", ")}`,
        { connection: conn });
    }
  }

  // Removable media: scan newly appeared volumes
  for (const v of vols) {
    if (!v.removable || knownVolumes.has(v.mount)) continue;
    knownVolumes.add(v.mount);
    if (ticks < 2) continue; // skip initial enumeration
    log("info", "sensor", `Removable volume mounted: ${v.mount} (${v.label || "no label"})`, null);
    await runScan(v.mount, 3000, "usb");
  }
  for (const m of [...knownVolumes]) if (!vols.some(v => v.mount === m)) knownVolumes.delete(m);

  // Persistence check (every 30 ticks ≈ 2 min)
  if (ticks % 30 === 0) await checkPersistence();

  setHealth("database", "ok");
}

// ─── SCAN ─────────────────────────────────────────────────────────────────────
export async function runScan(root, limit = 4000, kind = "manual") {
  setHealth("scanner", "running");
  log("info", "scanner", `Scan started: ${root}`, null);
  let result;
  try {
    result = scanPath(root, limit);
    setHealth("scanner", "ok");
  } catch(e) {
    setHealth("scanner", "error");
    throw e;
  }

  let contained = 0;
  for (const f of result.findings) {
    let action = "flagged";
    try {
      if ((f.severity === "critical" || f.severity === "high") && data().settings.enforce_quarantine) {
        const dest = quarantine(f.file, QUARANTINE);
        action = `quarantined → ${path.basename(dest)}`;
        contained++;
      }
    } catch (e) {
      action = `quarantine failed: ${e.message}`;
    }
    await recordThreat({
      name: f.name,
      rule: f.rule,
      severity: f.severity,
      file: f.file,
      hash: f.hash,
      action,
      source: kind,
      surpriseBits: 0,
    });
  }

  const scan = push("scans", {
    root, kind,
    files: result.files,
    findings: result.findings.length,
    contained,
    ms: result.ms,
  });
  emit("scan", scan);
  log(
    result.findings.length ? "warn" : "info",
    "scanner",
    `Scan finished: ${result.files} files, ${result.findings.length} findings`,
    null
  );
  audit("scan_complete", { root, kind, files: result.files, findings: result.findings.length });
  return scan;
}

export function checkFile(file) { return inspect(file); }

// ─── STATE SNAPSHOT ───────────────────────────────────────────────────────────
export function state() {
  const d = data();
  return {
    host:     S.host(),
    belief,
    running,
    health,
    pendingApprovals: getPendingApprovals().map(a => ({
      id: a.id, action: a.action, description: a.description, detail: a.detail, at: a.at
    })),
    counts: {
      threats: d.threats.length,
      scans:   d.scans.length,
      events:  d.events.length,
    },
    metrics:  d.metrics.slice(-120),
    threats:  d.threats.slice(-100).reverse(),
    scans:    d.scans.slice(-50).reverse(),
    events:   d.events.slice(-200).reverse(),
    settings: d.settings,
  };
}

// ─── START ────────────────────────────────────────────────────────────────────
export function start() {
  if (running) return;
  running = true;
  setSetting("startedAt", new Date().toISOString());
  // Safe defaults on first run
  const s = data().settings;
  if (s.enforce_quarantine === undefined) setSetting("enforce_quarantine", false);
  if (s.enforce_block      === undefined) setSetting("enforce_block",      false);
  if (s.enforce_hold       === undefined) setSetting("enforce_hold",       true);
  if (s.thresh_low         === undefined) setSetting("thresh_low",         20);
  if (s.thresh_medium      === undefined) setSetting("thresh_medium",      45);
  if (s.thresh_high        === undefined) setSetting("thresh_high",        70);
  if (s.ai_enabled         === undefined) setSetting("ai_enabled",         true);
  if (!Array.isArray(s.allowlist))        setSetting("allowlist",          []);

  log("info", "engine", "Active-inference engine online — Monitor-only mode", null);
  setHealth("sensors", "ok");

  const loop = async () => {
    try {
      await tick();
    } catch (e) {
      setHealth("sensors", "error");
      log("error", "engine", `Sensor cycle failed: ${e.message}`, null);
    }
  };

  loop();
  const timer = setInterval(loop, 4000);

  // Baseline scan after 3 seconds (bounded)
  setTimeout(() => {
    const home = process.env.USERPROFILE || process.env.HOME || os.homedir();
    const dl = path.join(home, "Downloads");
    if (fs.existsSync(dl)) runScan(dl, 1500, "baseline").catch(() => {});
  }, 3000);

  return () => clearInterval(timer);
}
