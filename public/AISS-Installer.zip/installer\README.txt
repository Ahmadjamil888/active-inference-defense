AISS Installation Instructions
==============================

Windows Installation:
---------------------
1. Double-click Setup.cmd to launch the AISS Setup Wizard
2. Follow the wizard:
   - Accept the license agreement
   - Choose installation location (default: %LOCALAPPDATA%\Programs\AISS)
   - Select additional tasks:
     * Add 'aiss' command to PATH (recommended)
     * Create desktop shortcut
     * Create Start Menu shortcut
     * Install as Windows Service (auto-start)
3. Click Install and wait for completion
4. Click Finish to launch AISS (optional)

Starting AISS:
-------------
After installation, open a NEW Command Prompt or PowerShell and run:

    aiss start

The dashboard will automatically open at http://127.0.0.1:8179

Other Commands:
---------------
    aiss status   - Check if AISS is running
    aiss stop     - Stop the AISS engine
    aiss open     - Open the dashboard in browser
    aiss logs     - View recent logs
    aiss uninstall - Remove AISS from your system

System Requirements:
--------------------
- Windows 10 or 11 (64-bit)
- 4 GB RAM minimum
- 500 MB disk space
- Node.js 18+ (installer will download if not found)
- Administrator rights for installation

Troubleshooting:
----------------
- If 'aiss' command is not found, restart your terminal or add the installation folder to PATH manually
- If the dashboard doesn't open, check that the service is running with: aiss status
- For detailed logs, run: aiss logs

Data Privacy:
-------------
AISS runs entirely on your local machine. All data stays on your computer.
No telemetry or data is sent to external servers (except optional AI cloud features).
