// Tiny append-only JSON store — zero native dependencies.
import fs from "node:fs";
import path from "node:path";
import os from "node:os";

export const HOME = path.join(os.homedir(), ".aiss");
const FILE = path.join(HOME, "db.json");

const EMPTY = {
  events: [],
  threats: [],
  scans: [],
  metrics: [],
  alerts: [],
  assets: [],
  incidents: [],
  settings: {}
};
let db = { ...EMPTY };
let dirty = false;

export function load() {
  fs.mkdirSync(HOME, { recursive: true });
  try {
    db = { ...EMPTY, ...JSON.parse(fs.readFileSync(FILE, "utf8")) };
  } catch {
    db = JSON.parse(JSON.stringify(EMPTY));
  }
  return db;
}

export function data() {
  return db;
}

function trim(arr, max) {
  if (arr.length > max) arr.splice(0, arr.length - max);
}

export function push(table, row) {
  const item = { id: `${Date.now()}-${Math.random().toString(16).slice(2, 8)}`, at: new Date().toISOString(), ...row };
  if (!db[table]) db[table] = [];
  db[table].push(item);
  trim(db[table], table === "metrics" ? 720 : 500);
  dirty = true;
  return item;
}

export function update(table, id, updates) {
  if (!db[table]) return null;
  const idx = db[table].findIndex(i => i.id === id);
  if (idx === -1) return null;
  db[table][idx] = { ...db[table][idx], ...updates, at: new Date().toISOString() };
  dirty = true;
  return db[table][idx];
}

export function remove(table, id) {
  if (!db[table]) return false;
  const idx = db[table].findIndex(i => i.id === id);
  if (idx === -1) return false;
  db[table].splice(idx, 1);
  dirty = true;
  return true;
}

export function setSetting(k, v) {
  db.settings[k] = v;
  dirty = true;
}

export function save() {
  if (!dirty) return;
  dirty = false;
  fs.writeFileSync(FILE, JSON.stringify(db));
}

setInterval(() => save(), 4000).unref?.();
