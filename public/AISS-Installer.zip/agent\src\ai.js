// Cloud AI reasoning via the AISS public endpoint (Lovable AI gateway behind it).
// Falls back to local analysis if cloud is unavailable.
const BASE = process.env.AISS_CLOUD || "https://active-inference-defense.lovable.app";
import { analyzeThreat as localAnalyze } from "./local-ai.js";

export async function analyze(threat) {
  // Try cloud AI first
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 10000); // Shorter timeout for cloud
  try {
    const res = await fetch(`${BASE}/api/public/analyze`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        name: threat.name,
        rule: threat.rule,
        severity: threat.severity,
        file: threat.file,
        hash: threat.hash,
        action: threat.action,
      }),
      signal: ctrl.signal,
    });
    if (!res.ok) throw new Error("Cloud AI unavailable");
    const json = await res.json();
    return json.analysis || null;
  } catch {
    // Fallback to local analysis
    console.log("Cloud AI unavailable, using local analysis");
    return localAnalyze(threat);
  } finally {
    clearTimeout(t);
  }
}
