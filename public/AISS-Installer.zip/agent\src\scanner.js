// Real file scanner: walks a directory, hashes files and matches signatures.
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

// EICAR standard antivirus test string (harmless, industry standard).
const EICAR_SHA256 = "275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f";

const SIGNATURES = [
  { id: "EICAR-TEST", severity: "critical", sha256: EICAR_SHA256, name: "EICAR antivirus test file" },
  // Add more known bad hashes here
];

const CONTENT_RULES = [
  { id: "PS-ENCODED", severity: "high", re: /powershell(\.exe)?\s+-(enc|encodedcommand)\s+[A-Za-z0-9+/=]{40,}/i, name: "Obfuscated PowerShell payload" },
  { id: "DOWNLOAD-EXEC", severity: "high", re: /(Invoke-WebRequest|curl|wget)[^\n]{0,120}(\|\s*(sh|bash)|;\s*\.\/|Start-Process)/i, name: "Download-and-execute chain" },
  { id: "AUTORUN", severity: "medium", re: /\[autorun\][\s\S]{0,200}open\s*=/i, name: "Autorun launcher" },
  { id: "REVERSE-SHELL", severity: "critical", re: /(nc|ncat|netcat)\s+-[a-z]*e\s+\/bin\/(ba)?sh|socket\.socket\([^)]*\)[\s\S]{0,120}dup2/i, name: "Reverse shell" },
  { id: "RANSOM-NOTE", severity: "high", re: /your files have been encrypted|send .{0,20}bitcoin .{0,30}to decrypt/i, name: "Ransomware note" },
  { id: "KEYLOGGER", severity: "high", re: /SetWindowsHookEx\s*\(\s*WH_KEYBOARD|pynput\.keyboard|keylog/i, name: "Keylogging routine" },
  { id: "DLL-INJECTION", severity: "critical", re: /VirtualAlloc|WriteProcessMemory|CreateRemoteThread/i, name: "DLL injection pattern" },
  { id: "PROCESS-HOLLOWING", severity: "critical", re: /NtUnmapViewOfSection|NtCreateProcessEx/i, name: "Process hollowing" },
  { id: "CREDENTIAL-THEFT", severity: "critical", re: /CredEnumerate|CredReadDomainCredentials|mimikatz/i, name: "Credential theft" },
  { id: "SUSPICIOUS-REG", severity: "high", re: /RegSetValueEx.*CurrentVersion\\Run|reg add.*HKCU.*Run/i, name: "Registry persistence" },
  { id: "ENCRYPTION-LOOP", severity: "critical", re: /encrypt.*\.(doc|xls|pdf|jpg|png|mp4).*forEach|for.*file.*encrypt/i, name: "File encryption loop" },
  { id: "WORM-PROPAGATION", severity: "critical", re: /copy.*\*\.exe.*\$/i, name: "Worm propagation pattern" },
  { id: "HIDDEN-PROCESS", severity: "high", re: /CreateProcess.*CREATE_NO_WINDOW|STARTF_USESHOWWINDOW.*SW_HIDE/i, name: "Hidden process execution" },
  { id: "SUSPICIOUS-NET", severity: "medium", re: /http:\/\/[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}:[0-9]{4,5}/i, name: "Suspicious IP:port" },
  { id: "BASE64-PAYLOAD", severity: "medium", re: /[A-Za-z0-9+/]{500,}={0,2}/i, name: "Large base64 payload" },
];

const RISKY_EXT = new Set([".exe", ".scr", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".jar", ".hta", ".dll", ".sys", ".com", ".pif"]);
const TEXTY = new Set([".txt", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".py", ".sh", ".inf", ".ini", ".html", ".md", ""]);
const MAX_BYTES = 8 * 1024 * 1024;

export function sha256(file) {
  const h = crypto.createHash("sha256");
  h.update(fs.readFileSync(file));
  return h.digest("hex");
}

export function inspect(file) {
  const findings = [];
  let stat;
  try {
    stat = fs.statSync(file);
  } catch {
    return findings;
  }
  if (!stat.isFile() || stat.size > MAX_BYTES) return findings;
  const ext = path.extname(file).toLowerCase();
  let buf;
  try {
    buf = fs.readFileSync(file);
  } catch {
    return findings;
  }
  const hash = crypto.createHash("sha256").update(buf).digest("hex");
  
  // Check signatures
  for (const s of SIGNATURES) if (s.sha256 === hash) findings.push({ rule: s.id, name: s.name, severity: s.severity, file, hash });
  
  // Check PE header for suspicious characteristics
  if (buf.length > 64 && buf[0] === 0x4D && buf[1] === 0x5A) {
    findings.push({ rule: "PE-HEADER", name: "Windows PE executable", severity: "medium", file, hash });
    
    // Check for packing indicators
    const entropy = calculateEntropy(buf);
    if (entropy > 7.5) {
      findings.push({ rule: "PACKED-PE", name: `Packed executable (entropy: ${entropy.toFixed(2)})`, severity: "high", file, hash });
    }
  }
  
  // Check content rules for text files
  if (TEXTY.has(ext) || buf.subarray(0, 4096).every((b) => b === 9 || b === 10 || b === 13 || (b >= 32 && b < 127))) {
    const text = buf.toString("utf8", 0, Math.min(buf.length, 512 * 1024));
    for (const r of CONTENT_RULES) if (r.re.test(text)) findings.push({ rule: r.id, name: r.name, severity: r.severity, file, hash });
  }
  
  // Check for double extension masquerade
  if (RISKY_EXT.has(ext) && /\.(jpg|png|pdf|docx?|txt)\.[a-z0-9]+$/i.test(path.basename(file))) {
    findings.push({ rule: "DOUBLE-EXT", name: "Double extension masquerade", severity: "high", file, hash });
  }
  
  // Check for suspicious filenames
  const suspiciousNames = /update|install|patch|crack|keygen|loader|inject|hook|bypass|exploit|payload|shell|backdoor|trojan|malware|virus/i;
  if (suspiciousNames.test(path.basename(file, ext))) {
    findings.push({ rule: "SUSPICIOUS-NAME", name: "Suspicious filename pattern", severity: "medium", file, hash });
  }
  
  return findings;
}

function calculateEntropy(buffer) {
  const freq = new Array(256).fill(0);
  for (let i = 0; i < buffer.length; i++) {
    freq[buffer[i]]++;
  }
  let entropy = 0;
  for (let i = 0; i < 256; i++) {
    if (freq[i] > 0) {
      const p = freq[i] / buffer.length;
      entropy -= p * Math.log2(p);
    }
  }
  return entropy;
}

export function* walk(root, limit = 4000) {
  let count = 0;
  const stack = [root];
  while (stack.length) {
    const dir = stack.pop();
    let entries = [];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (e.isSymbolicLink()) continue;
      if (e.isDirectory()) {
        if (/^(node_modules|\.git|System Volume Information|proc|sys|dev|Windows|\$Recycle\.Bin|Program Files|Program Files \(x86\)|ProgramData)$/i.test(e.name)) continue;
        stack.push(full);
      } else if (e.isFile()) {
        if (++count > limit) return;
        yield full;
      }
    }
  }
}

export function scanPath(root, limit) {
  const started = Date.now();
  let files = 0;
  const findings = [];
  for (const f of walk(root, limit)) {
    files++;
    findings.push(...inspect(f));
  }
  return { root, files, findings, ms: Date.now() - started };
}

export function quarantine(file, quarantineDir) {
  fs.mkdirSync(quarantineDir, { recursive: true });
  const target = path.join(quarantineDir, `${Date.now()}-${path.basename(file)}.quarantined`);
  const data = fs.readFileSync(file);
  // Neutralise by XOR-encoding so the file can never execute from quarantine.
  const enc = Buffer.from(data.map((b) => b ^ 0x5a));
  fs.writeFileSync(target, enc);
  fs.unlinkSync(file);
  return target;
}

export function restoreFromQuarantine(quarantinePath, destPath) {
  const data = fs.readFileSync(quarantinePath);
  // Reverse XOR-encoding
  const original = Buffer.from(data.map((b) => b ^ 0x5a));
  fs.writeFileSync(destPath, original);
  fs.unlinkSync(quarantinePath);
  return destPath;
}
